package Model;


public class Emprestimo {
	
	private int valor;
	
	public Emprestimo(int valor) {
		this.valor = valor;
	}
	public int getValor() {
		return valor;
	}

}
