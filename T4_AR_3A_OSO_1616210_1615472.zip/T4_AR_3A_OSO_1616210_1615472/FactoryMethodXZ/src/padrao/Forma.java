package padrao;

public interface Forma {
	
	public double calcular(double altura,double lagura);
}
