package padrao;

public enum EnumTipo {
Quadrado,
Retangulo,
Triangulo;

}

