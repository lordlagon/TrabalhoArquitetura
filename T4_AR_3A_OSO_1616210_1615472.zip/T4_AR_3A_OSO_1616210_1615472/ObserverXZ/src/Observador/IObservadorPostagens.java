package Observador;

import Postagem.PostagemCorreiosObservavel;

public interface IObservadorPostagens  {
	
	public void atualizar();
	public void setPostagemObservada(PostagemCorreiosObservavel postagemObservada);
	
	


}
