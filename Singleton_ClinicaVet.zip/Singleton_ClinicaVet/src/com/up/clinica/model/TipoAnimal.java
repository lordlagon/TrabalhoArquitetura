package com.up.clinica.model;

public class TipoAnimal {

}
