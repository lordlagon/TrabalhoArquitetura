package defaul;

public enum EnumTipo {
Quad,
Retan,
Trian;
	

}

