
public interface IObservadorPostagens  {
	
	public void atualizar();
	public void setPostagemObservada(PostagemCorreiosObservavel postagemObservada);


}
