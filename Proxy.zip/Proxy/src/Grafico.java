
public interface Grafico {
	
	public int getAltura();
	
	public int getLargura();
	
	public String getCaminho();
	
	public void desenharImagem();

}
